<?php

session_start();
require_once 'classes/Product.php';
require_once 'classes/Transaction.php';

$productObj     = new Product();
$transactionObj = new Transaction();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId   = (int)($_POST['product_id'] ?? 0);
    $jumlah      = (int)($_POST['jumlah'] ?? 0);
    $keterangan  = trim($_POST['keterangan'] ?? '');

    $result = $transactionObj->tambahTransaksi($productId, $jumlah, $keterangan);

    $_SESSION['flash'] = [
        'type'    => $result['success'] ? 'success' : 'error',
        'message' => $result['message'],
    ];
    header('Location: transactions.php');
    exit;
}

$semuaProduk     = $productObj->semuaProduk();
$semuaTransaksi  = $transactionObj->semuaTransaksi();
$currentDate     = date('l, d F Y');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi | Inventaris Toko</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<?php include 'includes/sidebar.php'; ?>

<main class="main">
    <div class="topbar">
        <h1>🔄 Catat Transaksi</h1>
        <span class="date">📅 <?= $currentDate ?></span>
    </div>
    <div class="content">

        <?php
        if (!empty($_SESSION['flash'])) {
            $t = $_SESSION['flash']['type'] === 'success' ? 'flash-success' : 'flash-error';
            echo "<div class='flash {$t}'>" . htmlspecialchars($_SESSION['flash']['message']) . "</div>";
            unset($_SESSION['flash']);
        }
        ?>

        
        <div class="card">
            <div class="card-header">
                <h2>➖ Catat Pengurangan Stok</h2>
            </div>
            <div class="card-body">
                <form method="POST" action="transactions.php" id="formTransaksi">

                    <div class="form-group">
                        <label for="product_id">Pilih Produk *</label>
                        <select id="product_id" name="product_id" class="form-control" required
                                onchange="updateStokInfo(this)">
                            <option value="">-- Pilih Produk --</option>
                            <?php foreach ($semuaProduk as $p): ?>
                            <option value="<?= $p['id'] ?>"
                                    data-stok="<?= $p['stok'] ?>"
                                    data-menipis="<?= Product::isStokMenipis((int)$p['stok']) ? '1' : '0' ?>">
                                <?= $p['tipe'] === 'Laptop' ? '💻' : '📱' ?>
                                <?= htmlspecialchars($p['nama_produk']) ?>
                                (<?= htmlspecialchars($p['merek']) ?>) — Stok: <?= $p['stok'] ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    
                    <div id="stokInfo" style="display:none; margin-bottom:16px;
                         padding:10px 14px; background:#e3f2fd; border-radius:8px;
                         border-left:4px solid #1565c0; font-size:13px;">
                        Stok tersedia: <strong id="stokTersedia"></strong> unit
                    </div>
                    <div id="stokWarning" style="display:none; margin-bottom:16px;
                         padding:10px 14px; background:#fff3e0; border-radius:8px;
                         border-left:4px solid #f57c00; font-size:13px; color:#e65100;">
                        ⚠️ Produk ini sudah dalam kondisi <strong>Stok Menipis</strong>!
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="jumlah">Jumlah Dikurangi *</label>
                            <input type="number" id="jumlah" name="jumlah" class="form-control"
                                   placeholder="Contoh: 2" min="1" required>
                            <small style="color:#888; font-size:12px;">⚠️ Jumlah tidak boleh 0 atau negatif</small>
                        </div>
                        <div class="form-group">
                            <label for="keterangan">Keterangan</label>
                            <input type="text" id="keterangan" name="keterangan" class="form-control"
                                   placeholder="Contoh: Penjualan ke customer">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-danger">➖ Catat Pengurangan Stok</button>
                </form>
            </div>
        </div>

       
        <div class="card">
            <div class="card-header">
                <h2>📜 Riwayat Transaksi (<?= count($semuaTransaksi) ?> transaksi)</h2>
            </div>
            <div class="card-body" style="padding:0">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Produk</th>
                            <th>Tipe</th>
                            <th>Merek</th>
                            <th>Jumlah</th>
                            <th>Keterangan</th>
                            <th>Tanggal & Waktu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($semuaTransaksi)): ?>
                        <tr>
                            <td colspan="7" style="text-align:center; color:#aaa; padding:30px;">
                                Belum ada transaksi.
                            </td>
                        </tr>
                        <?php endif; ?>

                        <?php foreach ($semuaTransaksi as $i => $t): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><strong><?= htmlspecialchars($t['nama_produk']) ?></strong></td>
                            <td>
                                <span class="badge <?= $t['tipe'] === 'Laptop' ? 'badge-laptop' : 'badge-smartphone' ?>">
                                    <?= $t['tipe'] ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($t['merek']) ?></td>
                            <td style="color:#c62828; font-weight:bold;">-<?= $t['jumlah'] ?> unit</td>
                            <td><?= htmlspecialchars($t['keterangan'] ?: '-') ?></td>
                            <td style="font-size:12px; color:#888;">
                                <?= date('d/m/Y H:i', strtotime($t['tanggal'])) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

<script>
function updateStokInfo(select) {
    const option    = select.options[select.selectedIndex];
    const stok      = option.getAttribute('data-stok');
    const menipis   = option.getAttribute('data-menipis');
    const infoEl    = document.getElementById('stokInfo');
    const warnEl    = document.getElementById('stokWarning');
    const stokEl    = document.getElementById('stokTersedia');

    if (select.value) {
        infoEl.style.display = 'block';
        stokEl.textContent   = stok;
        warnEl.style.display = menipis === '1' ? 'block' : 'none';
    } else {
        infoEl.style.display = 'none';
        warnEl.style.display = 'none';
    }
}


document.getElementById('formTransaksi').addEventListener('submit', function(e) {
    const jumlah = parseInt(document.getElementById('jumlah').value);
    if (jumlah <= 0) {
        e.preventDefault();
        alert('❌ Jumlah tidak boleh 0 atau negatif!');
        return;
    }

    const select = document.getElementById('product_id');
    const stok   = parseInt(select.options[select.selectedIndex].getAttribute('data-stok'));
    if (jumlah > stok) {
        e.preventDefault();
        alert(`❌ Jumlah melebihi stok tersedia! Stok: ${stok} unit.`);
    }
});
</script>

</body>
</html>
