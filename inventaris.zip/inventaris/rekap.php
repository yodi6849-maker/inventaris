<?php
// rekap.php — Halaman Rekap Transaksi
session_start();
require_once 'classes/Product.php';
require_once 'classes/Transaction.php';

$productObj     = new Product();
$transactionObj = new Transaction();

$rekapTransaksi = $transactionObj->rekapTransaksi();
$semuaTransaksi = $transactionObj->semuaTransaksi();
$totalTerjual   = $transactionObj->totalUnitTerjual();
$hariIni        = $transactionObj->transaksiHariIni();
$stokMenipis    = $productObj->produkStokMenipis();
$currentDate    = date('l, d F Y');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Transaksi | Inventaris Toko</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<?php include 'includes/sidebar.php'; ?>

<main class="main">
    <div class="topbar">
        <h1>📋 Rekap Transaksi</h1>
        <span class="date">📅 <?= $currentDate ?></span>
    </div>
    <div class="content">

        <!-- ── KARTU RINGKASAN ────────────────────────────── -->
        <div class="stat-grid">
            <div class="stat-card blue">
                <div class="stat-icon">🔄</div>
                <div class="stat-info">
                    <label>Total Transaksi</label>
                    <div class="stat-value"><?= count($semuaTransaksi) ?></div>
                </div>
            </div>
            <div class="stat-card green">
                <div class="stat-icon">📦</div>
                <div class="stat-info">
                    <label>Total Unit Terjual</label>
                    <div class="stat-value"><?= $totalTerjual ?></div>
                </div>
            </div>
            <div class="stat-card orange">
                <div class="stat-icon">📅</div>
                <div class="stat-info">
                    <label>Transaksi Hari Ini</label>
                    <div class="stat-value"><?= $hariIni ?></div>
                </div>
            </div>
            <div class="stat-card red">
                <div class="stat-icon">⚠️</div>
                <div class="stat-info">
                    <label>Produk Stok Menipis</label>
                    <div class="stat-value"><?= count($stokMenipis) ?></div>
                </div>
            </div>
        </div>

        <!-- ── PERINGATAN STOK MENIPIS ─────────────────────── -->
        <?php if (!empty($stokMenipis)): ?>
        <div class="alert-menipis">
            <h3>⚠️ PERINGATAN: Stok Menipis!</h3>
            <p style="font-size:13px; color:#795548; margin-bottom:10px;">
                Produk-produk berikut membutuhkan restok segera:
            </p>
            <?php foreach ($stokMenipis as $p): ?>
                <span class="badge-menipis">
                    <?= htmlspecialchars($p['nama_produk']) ?> — Sisa: <?= $p['stok'] ?> unit
                </span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- ── REKAP PER PRODUK ────────────────────────────── -->
        <div class="card">
            <div class="card-header">
                <h2>📊 Rekap Per Produk</h2>
            </div>
            <div class="card-body" style="padding:0">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama Produk</th>
                            <th>Tipe</th>
                            <th>Merek</th>
                            <th>Jml Transaksi</th>
                            <th>Total Terjual</th>
                            <th>Sisa Stok</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rekapTransaksi as $i => $r):
                            $menipis = Product::isStokMenipis((int)$r['stok_tersisa']);
                        ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><strong><?= htmlspecialchars($r['nama_produk']) ?></strong></td>
                            <td>
                                <span class="badge <?= $r['tipe'] === 'Laptop' ? 'badge-laptop' : 'badge-smartphone' ?>">
                                    <?= $r['tipe'] === 'Laptop' ? '💻' : '📱' ?> <?= $r['tipe'] ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($r['merek']) ?></td>
                            <td><?= $r['jumlah_transaksi'] ?? 0 ?> kali</td>
                            <td><strong><?= $r['total_terjual'] ?? 0 ?></strong> unit</td>
                            <td><strong><?= $r['stok_tersisa'] ?></strong></td>
                            <td>
                                <?php if ($menipis): ?>
                                    <span class="badge badge-warning">⚠️ Stok Menipis</span>
                                <?php else: ?>
                                    <span class="badge badge-ok">✅ Aman</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ── RIWAYAT SEMUA TRANSAKSI ─────────────────────── -->
        <div class="card">
            <div class="card-header">
                <h2>📜 Riwayat Semua Transaksi</h2>
                <span style="font-size:13px;color:#888;"><?= count($semuaTransaksi) ?> transaksi</span>
            </div>
            <div class="card-body" style="padding:0">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Produk</th>
                            <th>Tipe</th>
                            <th>Jumlah</th>
                            <th>Keterangan</th>
                            <th>Tanggal & Waktu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($semuaTransaksi)): ?>
                        <tr>
                            <td colspan="6" style="text-align:center; color:#aaa; padding:30px;">
                                Belum ada transaksi.
                            </td>
                        </tr>
                        <?php endif; ?>

                        <?php foreach ($semuaTransaksi as $i => $t): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td>
                                <strong><?= htmlspecialchars($t['nama_produk']) ?></strong><br>
                                <small style="color:#888"><?= htmlspecialchars($t['merek']) ?></small>
                            </td>
                            <td>
                                <span class="badge <?= $t['tipe'] === 'Laptop' ? 'badge-laptop' : 'badge-smartphone' ?>">
                                    <?= $t['tipe'] ?>
                                </span>
                            </td>
                            <td style="color:#c62828; font-weight:bold;">-<?= $t['jumlah'] ?> unit</td>
                            <td><?= htmlspecialchars($t['keterangan'] ?: '-') ?></td>
                            <td style="font-size:12px; color:#888;">
                                <?= date('d/m/Y H:i:s', strtotime($t['tanggal'])) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

</body>
</html>
