<?php
// includes/layout.php
// Fungsi helper untuk layout (header & footer)

function renderHeader(string $pageTitle, string $activePage): void {
    $currentDate = date('l, d F Y');
    echo <<<HTML
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$pageTitle} | Inventaris Toko</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-brand">
        <h2>🏪 Inventaris<br>Toko Retail</h2>
        <span>BB244 · STIKOM Bali</span>
    </div>
    <nav class="nav-menu">
        <a href="index.php" class="nav-item {$_active($activePage, 'dashboard')}">
            <span class="icon">📊</span> Dashboard
        </a>
        <a href="products.php" class="nav-item {$_active($activePage, 'products')}">
            <span class="icon">📦</span> Kelola Produk
        </a>
        <a href="transactions.php" class="nav-item {$_active($activePage, 'transactions')}">
            <span class="icon">🔄</span> Transaksi
        </a>
        <a href="rekap.php" class="nav-item {$_active($activePage, 'rekap')}">
            <span class="icon">📋</span> Rekap Transaksi
        </a>
    </nav>
</aside>

<main class="main">
    <div class="topbar">
        <h1>{$pageTitle}</h1>
        <span class="date">📅 {$currentDate}</span>
    </div>
    <div class="content">
HTML;
}

// Helper untuk class 'active' pada nav
$_active = fn(string $current, string $page) => $current === $page ? 'active' : '';

function renderFlash(): void {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!empty($_SESSION['flash'])) {
        $type = $_SESSION['flash']['type'] === 'success' ? 'flash-success' : 'flash-error';
        $msg  = htmlspecialchars($_SESSION['flash']['message']);
        echo "<div class='flash {$type}'>{$msg}</div>";
        unset($_SESSION['flash']);
    }
}

function setFlash(string $type, string $message): void {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function renderFooter(): void {
    echo <<<HTML
    </div><!-- /content -->
</main><!-- /main -->
</body>
</html>
HTML;
}
