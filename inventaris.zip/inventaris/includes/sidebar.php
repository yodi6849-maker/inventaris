<?php
// includes/sidebar.php
$currentPage = basename($_SERVER['PHP_SELF']);
function isActive(string $file, string $current): string {
    return $file === $current ? 'active' : '';
}
?>
<aside class="sidebar">
    <div class="sidebar-brand">
        <h2>🏪 Inventaris<br>Toko Retail</h2>
        <span>BB244 · STIKOM Bali</span>
    </div>
    <nav class="nav-menu">
        <a href="index.php" class="nav-item <?= isActive('index.php', $currentPage) ?>">
            <span class="icon">📊</span> Dashboard
        </a>
        <a href="products.php" class="nav-item <?= isActive('products.php', $currentPage) ?>">
            <span class="icon">📦</span> Kelola Produk
        </a>
        <a href="transactions.php" class="nav-item <?= isActive('transactions.php', $currentPage) ?>">
            <span class="icon">🔄</span> Catat Transaksi
        </a>
        <a href="rekap.php" class="nav-item <?= isActive('rekap.php', $currentPage) ?>">
            <span class="icon">📋</span> Rekap Transaksi
        </a>
    </nav>
    <div style="padding:16px 20px; border-top:1px solid rgba(255,255,255,0.1); font-size:11px; color:rgba(255,255,255,0.4); line-height:1.6;">
        Pengembangan Web Sisi Server<br>
        UTS Semester Genap 2025/2026
    </div>
</aside>
