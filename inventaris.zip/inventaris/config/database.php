<?php
// config/database.php
// Konfigurasi koneksi ke database MySQL

class Database {
    private static $instance = null;
    private $connection;

    // Konfigurasi koneksi - sesuaikan dengan XAMPP kamu
    private $host     = 'localhost';
    private $dbname   = 'db_inventaris';
    private $username = 'root';
    private $password = ''; // Default XAMPP kosong

    // Konstruktor private (Singleton Pattern)
    private function __construct() {
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset=utf8mb4";
            $this->connection = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            die("<div style='color:red; padding:20px; font-family:sans-serif;'>
                <h3>❌ Koneksi Database Gagal</h3>
                <p>" . $e->getMessage() . "</p>
                <p>Pastikan XAMPP MySQL sudah aktif dan database <b>db_inventaris</b> sudah dibuat.</p>
            </div>");
        }
    }

    // Mendapatkan instance tunggal (Singleton)
    public static function getInstance(): Database {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    // Mendapatkan objek koneksi PDO
    public function getConnection(): PDO {
        return $this->connection;
    }
}
