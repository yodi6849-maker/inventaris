<?php
// products.php — Halaman Kelola Produk (CRUD)
session_start();
require_once 'classes/Product.php';

$productObj = new Product();
$editData   = null;
$errors     = [];

// ── PROSES FORM ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'tambah' || $action === 'edit') {
        $nama  = trim($_POST['nama_produk'] ?? '');
        $tipe  = $_POST['tipe'] ?? '';
        $merek = trim($_POST['merek'] ?? '');
        $harga = (float)($_POST['harga'] ?? 0);
        $stok  = (int)($_POST['stok'] ?? 0);

        if ($action === 'tambah') {
            $result = $productObj->tambahProduk($nama, $tipe, $merek, $harga, $stok);
        } else {
            $id     = (int)($_POST['id'] ?? 0);
            $result = $productObj->editProduk($id, $nama, $tipe, $merek, $harga, $stok);
        }

        $_SESSION['flash'] = [
            'type'    => $result['success'] ? 'success' : 'error',
            'message' => $result['message'],
        ];
        header('Location: products.php');
        exit;
    }

    if ($action === 'hapus') {
        $id     = (int)($_POST['id'] ?? 0);
        $result = $productObj->hapusProduk($id);
        $_SESSION['flash'] = [
            'type'    => $result['success'] ? 'success' : 'error',
            'message' => $result['message'],
        ];
        header('Location: products.php');
        exit;
    }
}

// ── AMBIL DATA EDIT ──────────────────────────────────────────────────────────
if (isset($_GET['edit'])) {
    $editData = $productObj->getProdukById((int)$_GET['edit']);
}

$semua       = $productObj->semuaProduk();
$currentDate = date('l, d F Y');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Produk | Inventaris Toko</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<?php include 'includes/sidebar.php'; ?>

<main class="main">
    <div class="topbar">
        <h1>📦 Kelola Produk</h1>
        <span class="date">📅 <?= $currentDate ?></span>
    </div>
    <div class="content">

        <?php
        if (!empty($_SESSION['flash'])) {
            $t = $_SESSION['flash']['type'] === 'success' ? 'flash-success' : 'flash-error';
            echo "<div class='flash {$t}'>" . htmlspecialchars($_SESSION['flash']['message']) . "</div>";
            unset($_SESSION['flash']);
        }
        ?>

        <!-- ── FORM TAMBAH / EDIT ─────────────────────────── -->
        <div class="card">
            <div class="card-header">
                <h2><?= $editData ? '✏️ Edit Produk' : '➕ Tambah Produk Baru' ?></h2>
                <?php if ($editData): ?>
                    <a href="products.php" class="btn btn-warning btn-sm">✕ Batal Edit</a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <form method="POST" action="products.php">
                    <input type="hidden" name="action" value="<?= $editData ? 'edit' : 'tambah' ?>">
                    <?php if ($editData): ?>
                        <input type="hidden" name="id" value="<?= $editData['id'] ?>">
                    <?php endif; ?>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="nama_produk">Nama Produk *</label>
                            <input type="text" id="nama_produk" name="nama_produk" class="form-control"
                                   placeholder="Contoh: MacBook Air M3"
                                   value="<?= htmlspecialchars($editData['nama_produk'] ?? '') ?>"
                                   required>
                        </div>
                        <div class="form-group">
                            <label for="merek">Merek *</label>
                            <input type="text" id="merek" name="merek" class="form-control"
                                   placeholder="Contoh: Apple"
                                   value="<?= htmlspecialchars($editData['merek'] ?? '') ?>"
                                   required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="tipe">Tipe Produk *</label>
                            <select id="tipe" name="tipe" class="form-control" required>
                                <option value="">-- Pilih Tipe --</option>
                                <option value="Laptop"      <?= ($editData['tipe'] ?? '') === 'Laptop' ? 'selected' : '' ?>>💻 Laptop</option>
                                <option value="Smartphone"  <?= ($editData['tipe'] ?? '') === 'Smartphone' ? 'selected' : '' ?>>📱 Smartphone</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="harga">Harga (Rp) *</label>
                            <input type="number" id="harga" name="harga" class="form-control"
                                   placeholder="Contoh: 15000000"
                                   value="<?= $editData['harga'] ?? '' ?>"
                                   min="0" required>
                        </div>
                    </div>

                    <div class="form-group" style="max-width:200px">
                        <label for="stok">Jumlah Stok *</label>
                        <input type="number" id="stok" name="stok" class="form-control"
                               placeholder="Contoh: 10"
                               value="<?= $editData['stok'] ?? '' ?>"
                               min="0" required>
                        <small style="color:#888; font-size:12px;">⚠️ Stok tidak boleh bernilai negatif</small>
                    </div>

                    <button type="submit" class="btn <?= $editData ? 'btn-warning' : 'btn-success' ?>">
                        <?= $editData ? '💾 Simpan Perubahan' : '➕ Tambah Produk' ?>
                    </button>
                </form>
            </div>
        </div>

        <!-- ── DAFTAR PRODUK ──────────────────────────────── -->
        <div class="card">
            <div class="card-header">
                <h2>📋 Daftar Semua Produk (<?= count($semua) ?> produk)</h2>
            </div>
            <div class="card-body" style="padding:0">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama Produk</th>
                            <th>Tipe</th>
                            <th>Merek</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($semua)): ?>
                        <tr><td colspan="8" style="text-align:center; color:#aaa; padding:30px;">Belum ada produk. Silakan tambahkan produk baru.</td></tr>
                        <?php endif; ?>

                        <?php foreach ($semua as $i => $p):
                            $menipis = Product::isStokMenipis((int)$p['stok']);
                        ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><strong><?= htmlspecialchars($p['nama_produk']) ?></strong></td>
                            <td>
                                <span class="badge <?= $p['tipe'] === 'Laptop' ? 'badge-laptop' : 'badge-smartphone' ?>">
                                    <?= $p['tipe'] === 'Laptop' ? '💻' : '📱' ?> <?= $p['tipe'] ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($p['merek']) ?></td>
                            <td>Rp <?= number_format($p['harga'], 0, ',', '.') ?></td>
                            <td><strong><?= $p['stok'] ?></strong></td>
                            <td>
                                <?php if ($menipis): ?>
                                    <span class="badge badge-warning">⚠️ Stok Menipis</span>
                                <?php else: ?>
                                    <span class="badge badge-ok">✅ Aman</span>
                                <?php endif; ?>
                            </td>
                            <td style="white-space:nowrap">
                                <a href="products.php?edit=<?= $p['id'] ?>" class="btn btn-primary btn-sm">✏️ Edit</a>
                                <form method="POST" action="products.php" style="display:inline"
                                      onsubmit="return confirm('Yakin hapus produk: <?= htmlspecialchars($p['nama_produk']) ?>?')">
                                    <input type="hidden" name="action" value="hapus">
                                    <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">🗑️ Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

<script>
// Validasi sisi client: cegah submit jika stok negatif
document.querySelector('form').addEventListener('submit', function(e) {
    const stok = parseInt(document.getElementById('stok').value);
    if (stok < 0) {
        e.preventDefault();
        alert('❌ Stok tidak boleh bernilai negatif/minus!');
    }
});
</script>

</body>
</html>
