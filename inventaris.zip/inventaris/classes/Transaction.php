<?php
// classes/Transaction.php
// Class OOP untuk mengelola transaksi (pengurangan stok)

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/Product.php';

class Transaction {
    private PDO $db;
    private Product $productObj;

    public function __construct() {
        $this->db        = Database::getInstance()->getConnection();
        $this->productObj = new Product();
    }

    // ── CREATE: Catat transaksi pengurangan stok ────────────────────────────
    public function tambahTransaksi(int $productId, int $jumlah, string $keterangan = ''): array {
        // VALIDASI: jumlah tidak boleh negatif atau nol (CPMK093)
        if ($jumlah <= 0) {
            return ['success' => false, 'message' => 'Jumlah pengurangan harus lebih dari 0 dan tidak boleh negatif!'];
        }

        // Cek produk ada
        $produk = $this->productObj->getProdukById($productId);
        if (!$produk) {
            return ['success' => false, 'message' => 'Produk tidak ditemukan!'];
        }

        // Cek apakah stok cukup
        if ($produk['stok'] < $jumlah) {
            return [
                'success' => false,
                'message' => "Stok tidak mencukupi! Stok tersedia: {$produk['stok']} unit."
            ];
        }

        // Mulai transaksi database (atomic)
        $this->db->beginTransaction();
        try {
            // 1. Kurangi stok produk
            $updateStmt = $this->db->prepare(
                "UPDATE products SET stok = stok - :jumlah WHERE id = :id"
            );
            $updateStmt->execute([':jumlah' => $jumlah, ':id' => $productId]);

            // 2. Catat ke tabel transaksi
            $insertStmt = $this->db->prepare(
                "INSERT INTO transactions (product_id, jumlah, keterangan) VALUES (:pid, :jumlah, :ket)"
            );
            $insertStmt->execute([
                ':pid'    => $productId,
                ':jumlah' => $jumlah,
                ':ket'    => htmlspecialchars($keterangan),
            ]);

            $this->db->commit();

            // Ambil stok terbaru setelah transaksi
            $stokBaru = $produk['stok'] - $jumlah;
            $pesan = "Transaksi berhasil! Stok '{$produk['nama_produk']}' berkurang {$jumlah} unit. Sisa stok: {$stokBaru} unit.";

            // Tambahkan peringatan jika stok menipis
            if (Product::isStokMenipis($stokBaru)) {
                $pesan .= " ⚠️ PERINGATAN: Stok Menipis!";
            }

            return ['success' => true, 'message' => $pesan, 'stok_baru' => $stokBaru];

        } catch (Exception $e) {
            $this->db->rollBack();
            return ['success' => false, 'message' => 'Transaksi gagal: ' . $e->getMessage()];
        }
    }

    // ── READ: Semua riwayat transaksi ───────────────────────────────────────
    public function semuaTransaksi(): array {
        $sql = "
            SELECT t.id, p.nama_produk, p.tipe, p.merek, t.jumlah, t.keterangan, t.tanggal
            FROM transactions t
            JOIN products p ON t.product_id = p.id
            ORDER BY t.tanggal DESC
        ";
        return $this->db->query($sql)->fetchAll();
    }

    // ── DASHBOARD: Rekap transaksi per produk ───────────────────────────────
    public function rekapTransaksi(): array {
        $sql = "
            SELECT
                p.nama_produk,
                p.tipe,
                p.merek,
                COUNT(t.id) AS jumlah_transaksi,
                SUM(t.jumlah) AS total_terjual,
                p.stok AS stok_tersisa
            FROM products p
            LEFT JOIN transactions t ON p.id = t.product_id
            GROUP BY p.id
            ORDER BY total_terjual DESC
        ";
        return $this->db->query($sql)->fetchAll();
    }

    // ── DASHBOARD: Total transaksi hari ini ─────────────────────────────────
    public function transaksiHariIni(): int {
        $stmt = $this->db->query(
            "SELECT COUNT(*) FROM transactions WHERE DATE(tanggal) = CURDATE()"
        );
        return (int) $stmt->fetchColumn();
    }

    // ── DASHBOARD: Total unit terjual keseluruhan ───────────────────────────
    public function totalUnitTerjual(): int {
        $stmt = $this->db->query("SELECT COALESCE(SUM(jumlah), 0) FROM transactions");
        return (int) $stmt->fetchColumn();
    }
}
