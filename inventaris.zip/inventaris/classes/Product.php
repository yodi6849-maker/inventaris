<?php
// classes/Product.php
// Class OOP untuk mengelola data produk

require_once __DIR__ . '/../config/database.php';

class Product {
    private PDO $db;
    private const LOW_STOCK_THRESHOLD = 5; // Ambang batas "Stok Menipis"

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    // ── CREATE: Tambah produk baru ──────────────────────────────────────────
    public function tambahProduk(string $nama, string $tipe, string $merek, float $harga, int $stok): array {
        // VALIDASI: tolak stok negatif (CPMK093)
        if ($stok < 0) {
            return ['success' => false, 'message' => 'Stok tidak boleh bernilai negatif/minus!'];
        }
        if (empty($nama) || empty($merek)) {
            return ['success' => false, 'message' => 'Nama produk dan merek tidak boleh kosong!'];
        }
        if ($harga < 0) {
            return ['success' => false, 'message' => 'Harga tidak boleh negatif!'];
        }

        $sql = "INSERT INTO products (nama_produk, tipe, merek, harga, stok) VALUES (:nama, :tipe, :merek, :harga, :stok)";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':nama'  => htmlspecialchars($nama),
            ':tipe'  => $tipe,
            ':merek' => htmlspecialchars($merek),
            ':harga' => $harga,
            ':stok'  => $stok,
        ]);

        return ['success' => true, 'message' => "Produk '{$nama}' berhasil ditambahkan!"];
    }

    // ── READ: Ambil semua produk ────────────────────────────────────────────
    public function semuaProduk(): array {
        $stmt = $this->db->query("SELECT * FROM products ORDER BY tipe, nama_produk");
        return $stmt->fetchAll();
    }

    // ── READ: Ambil produk berdasarkan ID ───────────────────────────────────
    public function getProdukById(int $id): array|false {
        $stmt = $this->db->prepare("SELECT * FROM products WHERE id = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    // ── UPDATE: Edit data produk ────────────────────────────────────────────
    public function editProduk(int $id, string $nama, string $tipe, string $merek, float $harga, int $stok): array {
        // VALIDASI: tolak stok negatif (CPMK093)
        if ($stok < 0) {
            return ['success' => false, 'message' => 'Stok tidak boleh bernilai negatif/minus!'];
        }
        if (empty($nama) || empty($merek)) {
            return ['success' => false, 'message' => 'Nama produk dan merek tidak boleh kosong!'];
        }

        $sql = "UPDATE products SET nama_produk=:nama, tipe=:tipe, merek=:merek, harga=:harga, stok=:stok WHERE id=:id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':nama'  => htmlspecialchars($nama),
            ':tipe'  => $tipe,
            ':merek' => htmlspecialchars($merek),
            ':harga' => $harga,
            ':stok'  => $stok,
            ':id'    => $id,
        ]);

        return ['success' => true, 'message' => "Produk berhasil diperbarui!"];
    }

    // ── DELETE: Hapus produk ────────────────────────────────────────────────
    public function hapusProduk(int $id): array {
        $produk = $this->getProdukById($id);
        if (!$produk) {
            return ['success' => false, 'message' => 'Produk tidak ditemukan!'];
        }

        $stmt = $this->db->prepare("DELETE FROM products WHERE id = :id");
        $stmt->execute([':id' => $id]);

        return ['success' => true, 'message' => "Produk '{$produk['nama_produk']}' berhasil dihapus!"];
    }

    // ── DASHBOARD: Produk dengan stok menipis (< 5) ─────────────────────────
    public function produkStokMenipis(): array {
        $stmt = $this->db->prepare(
            "SELECT * FROM products WHERE stok < :threshold ORDER BY stok ASC"
        );
        $stmt->execute([':threshold' => self::LOW_STOCK_THRESHOLD]);
        return $stmt->fetchAll();
    }

    // ── DASHBOARD: Ringkasan statistik ─────────────────────────────────────
    public function getStatistik(): array {
        $row = $this->db->query("
            SELECT
                COUNT(*) AS total_produk,
                SUM(CASE WHEN tipe='Laptop' THEN 1 ELSE 0 END) AS total_laptop,
                SUM(CASE WHEN tipe='Smartphone' THEN 1 ELSE 0 END) AS total_smartphone,
                SUM(stok) AS total_stok,
                SUM(CASE WHEN stok < 5 THEN 1 ELSE 0 END) AS produk_menipis
            FROM products
        ")->fetch();
        return $row;
    }

    // ── HELPER: Cek apakah stok menipis ────────────────────────────────────
    public static function isStokMenipis(int $stok): bool {
        return $stok < self::LOW_STOCK_THRESHOLD;
    }
}
