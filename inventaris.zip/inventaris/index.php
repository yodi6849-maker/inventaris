<?php
// index.php — Dashboard Utama
session_start();
require_once 'classes/Product.php';
require_once 'classes/Transaction.php';

$productObj     = new Product();
$transactionObj = new Transaction();

$statistik      = $productObj->getStatistik();
$stokMenipis    = $productObj->produkStokMenipis();
$rekapTransaksi = $transactionObj->rekapTransaksi();
$hariIni        = $transactionObj->transaksiHariIni();
$totalTerjual   = $transactionObj->totalUnitTerjual();

$currentDate = date('l, d F Y');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Inventaris Toko Retail</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<?php include 'includes/sidebar.php'; ?>

<main class="main">
    <div class="topbar">
        <h1>📊 Dashboard</h1>
        <span class="date">📅 <?= $currentDate ?></span>
    </div>
    <div class="content">

        <?php
        // Tampilkan flash message jika ada
        if (!empty($_SESSION['flash'])) {
            $type = $_SESSION['flash']['type'] === 'success' ? 'flash-success' : 'flash-error';
            echo "<div class='flash {$type}'>" . htmlspecialchars($_SESSION['flash']['message']) . "</div>";
            unset($_SESSION['flash']);
        }
        ?>

        <!-- ── KARTU STATISTIK ───────────────────────────── -->
        <div class="stat-grid">
            <div class="stat-card blue">
                <div class="stat-icon">📦</div>
                <div class="stat-info">
                    <label>Total Produk</label>
                    <div class="stat-value"><?= $statistik['total_produk'] ?></div>
                </div>
            </div>
            <div class="stat-card green">
                <div class="stat-icon">💻</div>
                <div class="stat-info">
                    <label>Laptop</label>
                    <div class="stat-value"><?= $statistik['total_laptop'] ?></div>
                </div>
            </div>
            <div class="stat-card purple">
                <div class="stat-icon">📱</div>
                <div class="stat-info">
                    <label>Smartphone</label>
                    <div class="stat-value"><?= $statistik['total_smartphone'] ?></div>
                </div>
            </div>
            <div class="stat-card orange">
                <div class="stat-icon">🏷️</div>
                <div class="stat-info">
                    <label>Total Stok</label>
                    <div class="stat-value"><?= $statistik['total_stok'] ?></div>
                </div>
            </div>
            <div class="stat-card red">
                <div class="stat-icon">⚠️</div>
                <div class="stat-info">
                    <label>Stok Menipis</label>
                    <div class="stat-value"><?= $statistik['produk_menipis'] ?></div>
                </div>
            </div>
            <div class="stat-card green">
                <div class="stat-icon">🔄</div>
                <div class="stat-info">
                    <label>Transaksi Hari Ini</label>
                    <div class="stat-value"><?= $hariIni ?></div>
                </div>
            </div>
        </div>

        <!-- ── PERINGATAN STOK MENIPIS (OTOMATIS) ───────── -->
        <?php if (!empty($stokMenipis)): ?>
        <div class="alert-menipis">
            <h3>⚠️ PERINGATAN: Stok Menipis!</h3>
            <p style="font-size:13px; color:#795548; margin-bottom:10px;">
                Produk berikut memiliki stok di bawah 5 unit. Segera lakukan restok!
            </p>
            <?php foreach ($stokMenipis as $p): ?>
                <span class="badge-menipis">
                    <?= htmlspecialchars($p['nama_produk']) ?> — Sisa: <?= $p['stok'] ?> unit
                </span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- ── DATA STOK SEMUA PRODUK ───────────────────── -->
        <div class="card">
            <div class="card-header">
                <h2>📦 Data Stok Produk</h2>
                <a href="products.php" class="btn btn-primary btn-sm">+ Tambah Produk</a>
            </div>
            <div class="card-body" style="padding:0">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama Produk</th>
                            <th>Tipe</th>
                            <th>Merek</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $semua = $productObj->semuaProduk();
                        foreach ($semua as $i => $p):
                            $menipis = Product::isStokMenipis((int)$p['stok']);
                        ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><strong><?= htmlspecialchars($p['nama_produk']) ?></strong></td>
                            <td>
                                <span class="badge <?= $p['tipe'] === 'Laptop' ? 'badge-laptop' : 'badge-smartphone' ?>">
                                    <?= $p['tipe'] === 'Laptop' ? '💻' : '📱' ?> <?= $p['tipe'] ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($p['merek']) ?></td>
                            <td>Rp <?= number_format($p['harga'], 0, ',', '.') ?></td>
                            <td><strong><?= $p['stok'] ?> unit</strong></td>
                            <td>
                                <?php if ($menipis): ?>
                                    <span class="badge badge-warning">⚠️ Stok Menipis</span>
                                <?php else: ?>
                                    <span class="badge badge-ok">✅ Aman</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ── REKAP TRANSAKSI ────────────────────────────── -->
        <div class="card">
            <div class="card-header">
                <h2>📋 Rekap Transaksi Per Produk</h2>
                <span style="font-size:13px;color:#888;">Total Unit Terjual: <strong><?= $totalTerjual ?></strong></span>
            </div>
            <div class="card-body" style="padding:0">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama Produk</th>
                            <th>Tipe</th>
                            <th>Jumlah Transaksi</th>
                            <th>Total Terjual</th>
                            <th>Sisa Stok</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rekapTransaksi as $i => $r): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><strong><?= htmlspecialchars($r['nama_produk']) ?></strong></td>
                            <td>
                                <span class="badge <?= $r['tipe'] === 'Laptop' ? 'badge-laptop' : 'badge-smartphone' ?>">
                                    <?= $r['tipe'] ?>
                                </span>
                            </td>
                            <td><?= $r['jumlah_transaksi'] ?? 0 ?> kali</td>
                            <td><?= $r['total_terjual'] ?? 0 ?> unit</td>
                            <td>
                                <strong><?= $r['stok_tersisa'] ?></strong>
                                <?php if (Product::isStokMenipis((int)$r['stok_tersisa'])): ?>
                                    <span class="badge badge-warning" style="margin-left:4px">⚠️ Menipis</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div><!-- /content -->
</main>

</body>
</html>
